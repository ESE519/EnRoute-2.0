#include "mbed.h"
#include "Servo.h"
 
Servo servo1(p25);
Servo servo2(p24);
Servo servo3(p23);
Servo servo4(p22);
 
int main() {
    while(1) {
         for(int i=0; i<100; i++) {
             servo1 = i/100.0;
             servo2 = i/100.0;
             //servo3 = i/100.0;
             //servo4 = i/100.0;
             wait(0.01);
         }
         for(int i=100; i>0; i--) {
             //servo1 = i/100.0;
             //servo2 = i/100.0;
             servo3 = i/100.0;
             servo4 = i/100.0;
             wait(0.01);
         }
     }
}