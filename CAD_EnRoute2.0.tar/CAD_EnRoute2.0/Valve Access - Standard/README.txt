Valve Access:
These small pieces forms the link with the servo with the help of a 2*4-40 1/2" bolts and corresponding nuts & washers.
This is applicable to any type of valve in this testbed.

EnRoute2.0