1) Due to the sheer dimensions of the walls, they were not laser cut but measured and cut using a power saw. 
2) The design is such that the front cover can be completely taken out but unscrewing from the L-brackets.
3) These L-brackets are screwed in with our custom designed nut-lock.

EnRoute2.0