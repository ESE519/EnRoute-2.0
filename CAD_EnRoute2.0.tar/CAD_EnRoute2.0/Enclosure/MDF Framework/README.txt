Enclosure Front:
1) In red, the MDF pieces that form the framework including the handles and connecting pieces.
2) In white, how the complete front looks. The center window is 2*(32X16) clear acrylic sheets.

EnRoute2.0