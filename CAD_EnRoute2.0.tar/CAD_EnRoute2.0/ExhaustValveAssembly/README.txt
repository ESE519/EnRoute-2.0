Single Exhaust Valve:
The only main difference with the Exhaust Valve is the perforated wall that helps ease pressure in the unit. 
This piece can be seen in yellow.

EnRoute2.0 