
/* Temperature Sensor */
class TEMP_SENSOR
{
public:
    float temp_c;
    float temp_f;
    int temp_raw;
    TEMP_SENSOR(PinName pin);
    void get_temp();
private:
    AnalogIn _pin;
};

/* Flow Meter */
class FLOW_METER
{
public:
    Timer time;    
    float t_period;
    float t_freq;
    FLOW_METER(PinName pin);
    void ISR();
private:
    InterruptIn _pin;
};

/* Servo Valve */
class SERVO_VALVE
{
public:
    float angle;
    signed int orientation;
    SERVO_VALVE(PinName pin, signed int orient);
    void set_angle(float desAngle);
private:
    PwmOut _pin;
};

/* Variable Blower */
class VAR_BLOWER
{
public:
    int speed;
    VAR_BLOWER(PinName pin);
    void set_speed(float dutyCycle);
private:
   PwmOut _pin;
};

/* Binary Blower */
class BIN_BLOWER
{
public:
    int state;
    BIN_BLOWER(PinName pin);
    void set();
    void clear();
    void toggle();
private:
    DigitalOut _pin;
};