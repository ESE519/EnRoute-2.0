
#define THIS_MBED_IDENTIFIER 29     // mbed Identifier Number
#define THIS_MBED_TX_LEN 7          // Transmit packet length

#define OVERFLOW_TIME_US 2000000    // Flow meter overflow time (us)