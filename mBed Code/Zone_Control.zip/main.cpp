/*
EnRoute 2.0 DUAL ZONE MBED CONTROLLER
Authors:  Dan Wheeler, Neel D Shah, Larry Vadakedathu

This program acts as the main control function for the EnRoute 2.0 project, with
regards to the dual-zone control mbeds.  These mbeds control two seperate rooms 
where each room has one damper valve, one flow meter, and one temperature sensor.

The purpose of the mbed is only to read data, relay the data to the host computer
(currently over serial using custom packets), and recieve data from the host computer
to drive outputs (i.e. servo valve).

Each mbed has a specific header file (Control_XX.h, where XX represents the mbed 
specific number.  You must include the appropriate header file when compiling the
mbed, or communication will not work correctly.
*/
#include "mbed.h"
#include<iostream>
#include<stdio.h>
#include<PERIPHERALS.h>
#include<Control_20.h>

Serial HVAC(p9,p10);        // Tx, Rx
//Serial HVAC(USBTX,USBRX);   // Testing directly over Serial
DigitalOut ledRX(LED1);     // LED to toggle on packet receive

/*
DigitalOut one(p15);        // Set analog pins as digital out
DigitalOut two(p16);        // Suggested to reduce noise in signal
DigitalOut three(p17);      // ^
DigitalOut four(p19);       // ^
*/

int main () 
{
    //
    // COMPONENT DECLARATIONS
    //
    TEMP_SENSOR t1(p20);    // Initialize temperature sensors
    TEMP_SENSOR t2(p18);    // ^
    SERVO_VALVE v1(p21,1);  // Initialize servo valves
    SERVO_VALVE v2(p22,1); // ^
    FLOW_METER fm1(p8);     // Initialize flow meters
    FLOW_METER fm2(p7);     // ^ 
    
    //
    // INITIAL DECLARATIONS
    //
    int buffer[THIS_MBED_TX_LEN];       // Transmission buffer
    buffer[0] = THIS_MBED_IDENTIFIER;   // First byte should be mbed identifier number
    ledRX = 1;
      
    while(1)
    {
        // 
        // FLOW METER OVERFLOW TIMERS
        //
        if ( fm1.time.read_us() > OVERFLOW_TIME_US )    // If time since interrupt exceeds OVERFLOW_TIME ...
        {
            fm1.t_freq = 0;                             // ... set frequency to zero
            fm1.time.reset();                           // ... and reset timer
        }
        if ( fm2.time.read_us() > OVERFLOW_TIME_US )    // ^
        {
            fm2.t_freq = 0;                             // ^
            fm2.time.reset();                           // ^
        }    
  
        // 
        // BUILD BUFFER
        //
        t1.get_temp();      // Read temperature sensor analog values
        t2.get_temp();      // ^
              
        buffer[1] = t1.temp_raw>>8;         // Place raw_temp in buffer, split into 8-bit pieces
        buffer[2] = t1.temp_raw;            // ^
        buffer[3] = t2.temp_raw>>8;         // ^
        buffer[4] = t2.temp_raw;            // ^    
        buffer[5] = fm1.t_freq;             // Place frequency in buffer
        buffer[6] = fm2.t_freq;             // ^
    
        //
        // RECEIVE AND TRANSMIT DATA
        //
        if ( HVAC.readable() )                                  // If there is data to be read
        {
            ledRX = !ledRX;                                     // Toggle the LED
            if ( HVAC.getc() == THIS_MBED_IDENTIFIER )          // If first byte must be the mbed identifier number ...
            {
                v1.set_angle( HVAC.getc() );                    // Read angle from HVAC controller and set
                v2.set_angle( HVAC.getc() );                    // ^
            
                for( int i = 0 ; i < THIS_MBED_TX_LEN ; i++ )   // Transmit data back to computer (temp and flow)
                {
                    HVAC.putc(buffer[i]);
                }
            }
        }        
    }
}

