#include "mbed.h"
#include <PERIPHERALS.h>


/* Temperature Sensor */
TEMP_SENSOR::TEMP_SENSOR(PinName pin) : _pin(pin) {}    // Init temperature sensor by setting ADC pin
void TEMP_SENSOR::get_temp()        // Get the temperature
{
    temp_raw = _pin.read_u16();     // Read the raw 16-bit value
    temp_c = (temp_raw*330.0)-50;   // Convert to celcius temperature ...
    temp_f = temp_c*1.8+32;         // ... and farenheit temperature
}

/* Flow Meter */
void FLOW_METER::ISR()              // Interrupt Service Routine
{
    t_period = time.read_us();      // Read elapsed time in micro-seconds
    t_freq = (1/t_period)*1000000;  // Convert to frequency
    time.reset();                   // Reset the timer
}
FLOW_METER::FLOW_METER(PinName pin) : _pin(pin) // Init flow meter by setting interrupt DigitalIn pin 
{
    _pin.mode(PullDown);                // Set pin mode to pulldown
    _pin.rise(this,&FLOW_METER::ISR);   // Attach interrupt handler
    time.start();                       // Start the timer
}

/* Servo Valve */
SERVO_VALVE::SERVO_VALVE(PinName pin, signed int orient) : _pin(pin)    // Init servo valve by setting PWM pin and orientation
{
    orientation = orient;   // Some valves may be 90deg out of phase with others
    _pin.period(0.020);     // Servo requires PWM period 20 ms
    set_angle(0);           // Set the angle to 0
}
void SERVO_VALVE::set_angle(float desAngle)         // Set the valve angle
{
    angle = desAngle;                               // Store the angle
    if( orientation == 1 )                          // If you are oriented normally ...
    {
        _pin.pulsewidth( (angle+130) / 100000 );    // ... pulsewidth (0.0013,0.0022) maps to angle (0,90)
    }
    else if( orientation == -1 )
    {
        _pin.pulsewidth( (220-angle) / 100000 );    // else pulsewidth (0.0013,0.0022) maps to angle (90,0)
    }
}

/* Variable Blower */
VAR_BLOWER::VAR_BLOWER(PinName pin) : _pin(pin)     // Init variable blower (speed controlled)
{
    _pin.period(0.020);                             // Set pin period to 20 ms
    _pin.pulsewidth(0.020*0.0);                     // Init pulsewidth at 0% (blower off)
    speed = 0;                                      // Set speed as 0
}
void VAR_BLOWER::set_speed(float dutyCycle)         // Set the blower speed 
{
    speed = (int)dutyCycle;                         // Store the speed
    _pin.pulsewidth(0.020*dutyCycle/100);           // Set duty cycle (PC should limit 60% -> 100%
}

/* Binary Blower */
BIN_BLOWER::BIN_BLOWER(PinName pin) : _pin(pin)     // Init binary blower (ON / OFF)
{
    state = 0;                                      // Initialize blower to off
    _pin = 0;                                       // ^
}
void BIN_BLOWER::set()      // Turn on the blower
{
    state = 1;
    _pin = 1;
}
void BIN_BLOWER::clear()    // Turn off the blower
{
    state = 0;
    _pin = 0;
}
void BIN_BLOWER::toggle()   // Toggle the blower
{
    state = !state;
    _pin = state;
}