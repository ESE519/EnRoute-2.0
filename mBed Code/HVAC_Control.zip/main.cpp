/*
EnRoute 2.0 HVAC MBED CONTROLLER
Authors:  Dan Wheeler, Neel D Shah, Larry Vadakedathu

This program acts as the main control function for the EnRoute 2.0 project, with
regards to the HVAC.  This mbed controls multiple blowers, several valves, and 
reading multiple temperature sensors.

This mbed serves as the communication link between the PC and the EnRoute 2.0 system
as a whole, while also controlling the HVAC components.  Data is transmit from the PC,
and this mbed relays the required information to the zone control mbeds.  It also reads
data from the zone mbeds and relays it to the controlling PC.
*/
#include "mbed.h"
#include "EthernetInterface.h"
#include<iostream>
#include<stdio.h>
#include<PERIPHERALS.h>
#include<HVAC.h>

Serial ZONE1(p28,p27);          // Tx, Rx
Serial ZONE2(p13,p14);          // Tx, Rx
Serial PC(USBTX,USBRX);         // Tx, Rx

DigitalOut ledRX1(LED1);        // Indicator LEDs for communication         
DigitalOut ledRX2(LED2);        // ^
DigitalOut ledRXPC(LED3);       // ^
DigitalOut ledHeater(LED4);
//DigitalOut comm(p30);           // Indicator LED IP comm vs. Serial Comm 
DigitalOut hotCold(p8);        // Indicator LED for heating or cooling
DigitalOut z1RX(p5);           // Indicator LEDS for correct packets received
DigitalOut z2RX(p6);
DigitalOut pcRX(p7);
DigitalIn IP_Serial(p15);       // Digital In for IP v. Serial Comm

extern "C" void mbed_mac_address(char *mac) { mac[0]=0x2a; mac[1]=0x00; mac[2]=0x00; mac[3]=0x9b; mac[4]=0x50; mac[5]=0x0d; } //Setting a MAC address

int main () 
{
    //
    // COMPONENT DECLARATIONS
    //
    VAR_BLOWER b1(p21);         // Initialize supply variable blower 
    BIN_BLOWER b2(p29);          // Initialize return binary blower
    BIN_BLOWER b3(p30);          // Initialize cooler supply binary blower
    SERVO_VALVE v1(p23,-1);     // Exhaust valve (reverse oriented) //Placed on eagle 
    SERVO_VALVE v2(p24,1);      // Inlet Valve                      //Placed on eagle 
    SERVO_VALVE dbv1(p25,1);    // Double Valve                     //Placed on eagle 
    TEMP_SENSOR t1(p20);        // Initialize temperature sensors //placed on eagle
    TEMP_SENSOR t2(p18);        // ^                               //Placed on eagle 
    FLOW_METER fm1(p12);         // Initialize flow meter        //Placed on eagle 
    CURRENT_SENSOR i1(p16);
    CURRENT_SENSOR i2(p17);
    v1.set_angle(0);            // Initialize valve angles open
    v2.set_angle(0);
    dbv1.set_angle(90);
    
    BIN_BLOWER heater(p11);      // Heater acts like a binary blower
    heater.clear();             // Initialize it off
    
    //
    // INITIAL DECLARATIONS
    // 
    char buffer_zone1[ZONE_1_TX_LEN];    // Transmission buffer ZONE1
    char buffer_zone2[ZONE_2_TX_LEN];    // Transmission buffer ZONE2
    char buffer_pc[PC_TX_LEN];           // Transmission buffer PC (12 from each zone)   
    char temp_buffer[20];
    int cnt = 0;
    
    buffer_zone1[0] = ZONE_1_IDENTIFIER;    // Specify buffer identifiers
    buffer_zone2[0] = ZONE_2_IDENTIFIER;    // ^
    buffer_pc[0] = ZONE_1_IDENTIFIER;       // ^
    buffer_pc[7] = ZONE_2_IDENTIFIER;       // ^
    buffer_pc[14] = THIS_MBED_IDENTIFIER;   // ^
   
    buffer_zone1[1] = 0;    // Initial Valve positions
    buffer_zone1[2] = 0;    // ^
    buffer_zone2[1] = 0;    // ^
    buffer_zone2[2] = 0;    // ^
    
    ledRX1 = ledRX2 = ledRXPC = ledHeater = 1;      // Turn LEDs on at first
    hotCold = 1;                                    // Start out cooling
    //comm = 1;                                       // Start on Serial
    z1RX = z2RX = pcRX = 1;
    
    wait(1);
    
    //
    // ETHERNET INITIALIZE
    //
    EthernetInterface eth;
    eth.init(); //Use DHCP
    //eth.connect();
    int response = eth.connect(5000);
    char mac[6];
    mbed_mac_address(mac);
    UDPSocket server;
    server.set_blocking(false,1500);
    server.bind(ECHO_SERVER_PORT_RECEIVE);
    Endpoint client;
    
    //wait(1);                // Pause for one second
    
    ledRX1 = ledRX2 = ledRXPC = ledHeater = 0;      // Turn LEDs on at first
    
    while(1)
    {
        // 
        // FLOW METER OVERFLOW TIMERS
        //
        if ( fm1.time.read_us() > OVERFLOW_TIME_US )    // If time since interrupt exceeds OVERFLOW_TIME ...
        {
            fm1.t_freq = 0;                             // ... set frequency to zero
            fm1.time.reset();                           // ... and reset timer
        }
        // 
        // ZONE1 COMMUNICATION
        //
        for ( int i = 0 ; i < ZONE_1_TX_LEN ; i++ ) // Write to zone 1
        {
            ZONE1.putc(buffer_zone1[i]);            // ^
        }
        wait(0.01);                                 // Necessary delay
        while( !ZONE1.readable() );                 // Wait for data to be available
        wait(0.01); 
        cnt = 0;
        while ( ZONE1.readable() )
        {
            temp_buffer[cnt] = ZONE1.getc();
            cnt++;    
            wait(0.001);   
        }
        if ( cnt == ( ZONE_1_RX_LEN ) )         // Received correct number of bytes
        {
            z1RX = 0;
            if ( temp_buffer[0] == ZONE_1_IDENTIFIER )    // If we got the correct packet identifier
            {
                buffer_pc[1] = temp_buffer[1];            // Read data and store for transmission
                buffer_pc[2] = temp_buffer[2];            // ^
                buffer_pc[3] = temp_buffer[3];            // ^
                buffer_pc[4] = temp_buffer[4];            // ^
                buffer_pc[5] = temp_buffer[5];            // ^
                buffer_pc[6] = temp_buffer[6];            // ^
            }  
        }
        else
            z1RX = 1;
        ledRX1 = !ledRX1;                           // Toggle LED
        // 
        // ZONE2 COMMUNICATION
        //
        for ( int i = 0 ; i < ZONE_2_TX_LEN ; i++ ) // Write to zone 2
        {
            ZONE2.putc(buffer_zone2[i]);            // ^
        }
        wait(0.01);                                 // Necessary delay
        while( !ZONE2.readable() )                  // Wait for data to be available
        wait(0.01);
        cnt = 0;
        while ( ZONE2.readable() )
        {
            temp_buffer[cnt] = ZONE2.getc();
            cnt++;      
            wait(0.001); 
        }
        if ( cnt == ( ZONE_2_RX_LEN ) )         // Received correct number of bytes
        {
            z2RX = 0;
            if ( temp_buffer[0] == ZONE_2_IDENTIFIER )    // If we got the correct packet identifier
            {
                buffer_pc[8] = temp_buffer[1];            // Read data and store for transmission
                buffer_pc[9] = temp_buffer[2];            // ^
                buffer_pc[10] = temp_buffer[3];            // ^
                buffer_pc[11] = temp_buffer[4];            // ^
                buffer_pc[12] = temp_buffer[5];            // ^
                buffer_pc[13] = temp_buffer[6];            // ^
            }  
        }
        else
            z2RX = 1;
        ledRX2 = !ledRX2;                           // Toggle LED    
        //
        // DATA FROM HVAC CONTROL BE READ HERE
        //        
        t1.get_temp();      // Read temperature sensor analog values
        t2.get_temp();
        i1.get_current();   // Read current sensor analog values
        i2.get_current();
              
        buffer_pc[15] = t1.temp_raw>>8;         // Place raw_temp in buffer, split into 8-bit pieces
        buffer_pc[16] = t1.temp_raw;            // ^
        buffer_pc[17] = t2.temp_raw>>8;         // ^
        buffer_pc[18] = t2.temp_raw;            // ^
        buffer_pc[19] = fm1.t_freq;             // ^
        buffer_pc[20] = i1.raw>>8;
        buffer_pc[21] = i1.raw;
        buffer_pc[22] = i2.raw>>8;
        buffer_pc[23] = i2.raw;
    
        //
        // PC COMMUNICATION
        //
        // Serial Communication
        if ( IP_Serial)
        {
            cnt = 0;
            while ( PC.readable() )
            {
                temp_buffer[cnt] = PC.getc();
                cnt++;        
                wait(0.01); 
            }
            if ( cnt > 0 )
            {
                if ( cnt == (PC_RX_LEN ) )         // Received correct number of bytes
                {
                    pcRX = 0;
                    
                    if ( temp_buffer[0] == THIS_MBED_IDENTIFIER )    // If we got the correct packet identifier
                    {
                        buffer_zone1[1] = temp_buffer[1];            // Read data and store for transmission
                        buffer_zone1[2] = temp_buffer[2];            // ^
                        buffer_zone2[1] = temp_buffer[3];            // ^
                        buffer_zone2[2] = temp_buffer[4];            // ^
                        v1.set_angle( temp_buffer[5] );              // Set angle on valves
                        v2.set_angle( temp_buffer[6] );              // ^
                        b1.set_speed( temp_buffer[7] );              // Control variable blower
                        if ( temp_buffer[8] == 1 )                   // Control binary blowers
                            b2.set();                           // ^
                        else                                    // ^
                            b2.clear();                         // ^
                        if ( temp_buffer[9] == 1 )                   // ^
                            b3.set();                           // ^
                        else                                    // ^
                            b3.clear();                         // ^
                        dbv1.set_angle( temp_buffer[10] );
                        
                        //
                        // HANDLE HEATER TEMP LIMITS
                        //
                        if ( dbv1.angle == 0 )
                        {
                            hotCold = 0;
                            if ( t1.temp_c < HEATER_LOW_SP && heater.state == 0 )
                            {
                                ledHeater = !ledHeater;
                                heater.set();
                            }
                            else if ( t1.temp_c > HEATER_HIGH_SP && heater.state == 1 )
                                heater.clear();                           
                        }
                        else
                        {
                            heater.clear();
                            hotCold = 1;
                        }
                     
                        for ( int i = 0 ; i < PC_TX_LEN ; i++ ) // Write to the PC
                        {
                            PC.putc(buffer_pc[i]);              // ^
                        }
                    }
                
                }
                else
                    pcRX = 1;
                ledRXPC = !ledRXPC;                             // Toggle the LED
            }
        }
        // IP Communication
        else
        {
            int n = server.receiveFrom(client, temp_buffer, PC_RX_LEN);
            if ( n == (PC_RX_LEN ) )         // Received correct number of bytes
            {
                pcRX = 0;
                if ( temp_buffer[0] == THIS_MBED_IDENTIFIER )    // If we got the correct packet identifier
                {
                    buffer_zone1[1] = temp_buffer[1];            // Read data and store for transmission
                    buffer_zone1[2] = temp_buffer[2];            // ^
                    buffer_zone2[1] = temp_buffer[3];            // ^
                    buffer_zone2[2] = temp_buffer[4];            // ^
                    v1.set_angle( temp_buffer[5] );              // Set angle on valves
                    v2.set_angle( temp_buffer[6] );              // ^
                    b1.set_speed( temp_buffer[7] );              // Control variable blower
                    if ( temp_buffer[8] == 1 )                   // Control binary blowers
                        b2.set();                           // ^
                    else                                    // ^
                        b2.clear();                         // ^
                    if ( temp_buffer[9] == 1 )                   // ^
                        b3.set();                           // ^
                    else                                    // ^
                        b3.clear();                         // ^
                    dbv1.set_angle( temp_buffer[10] );
                    
                    //
                    // HANDLE HEATER TEMP LIMITS
                    //
                    if ( dbv1.angle == 0 )
                    {
                        hotCold = 0;
                        if ( t1.temp_c < HEATER_LOW_SP && heater.state == 0 )
                        {
                            ledHeater = !ledHeater;
                            heater.set();
                        }
                        else if ( t1.temp_c > HEATER_HIGH_SP && heater.state == 1 )
                            heater.clear();                           
                    }
                    else
                    {
                        heater.clear();
                        hotCold = 1;
                    }
                }       
                // Send to computer
                server.bind(ECHO_SERVER_PORT_SEND);
                server.sendTo(client, buffer_pc, PC_TX_LEN);
            }
            else
            {
                pcRX = 1;
            }
            ledRXPC = !ledRXPC;
        }
    }
}

