
#define THIS_MBED_IDENTIFIER 39     // mbed Identifier Number
#define ZONE_1_IDENTIFIER 29        // Zone1 mbed Identifier Number
#define ZONE_2_IDENTIFIER 20        // Zone2 mbed Identifier Number

#define ZONE_1_TX_LEN 3             // Zone1 Transmit Packet Length
#define ZONE_1_RX_LEN 7             // Zone1 Receive Packet Length
#define ZONE_2_TX_LEN 3             // Zone2 Transmit PAcket Length
#define ZONE_2_RX_LEN 7             // Zone2 Receive Packet Length
#define PC_TX_LEN 24                // 14 from the zones 2x [Identifier temp1 temp1 temp2 temp2 flow1 flow2] and 2 from HVAC [Identifier temp1 temp1 temp2 temp2 flow1 current1 current1 current2 current2]
#define PC_RX_LEN 11                // PC Receive Packet Length

#define HEATER_HIGH_SP 40
#define HEATER_LOW_SP 37

#define OVERFLOW_TIME_US 2000000    // Flow meter overflow time (us)

#define ECHO_SERVER_PORT_RECEIVE   25000
#define ECHO_SERVER_PORT_SEND 27000
